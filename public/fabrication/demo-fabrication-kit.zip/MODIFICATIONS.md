# PawStory fabrication modifications

This package adapts the structural ideas demonstrated by scadqr demo_tag.scad:
a rounded baseplate, attachment holes, and protected QR padding.

Upstream project: https://github.com/xypwn/scadqr
Pinned commit: a27e1feeed8b048b730fcd2620c0021b3b52a283
Author: Darwin Schuppan and contributors
License: MIT (see scadqr-MIT-LICENSE.txt)

PawStory implementation changes:
- Reimplemented the geometry in TypeScript/Three.js; no upstream SCAD source is bundled.
- Uses a rectangular two-hole plate and a separate laser panel.
- Uses one shared TagParameters model for preview and STL generation.
- Generates a layered SVG with an actual memory URL QR code and outline-only ASCII label.
- Adds project-created flexible-link reference geometry for visualization only.
- Parameters: 60 × 42 × 3 mm; panel 1.2 mm

Not validated for production wear: printer/material tolerances, laser settings, strength,
waterproofing, pet comfort, and garment fit all require physical prototyping.
No G-code, laser power, or speed settings are included.
